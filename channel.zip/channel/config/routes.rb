Rails.application.routes.draw do
  resources :chanels
  resources :broadcasts
end
